// backend/index.js
import express from "express";
import multer from "multer";
import cors from "cors";
import mysql from "mysql2/promise";
import path from "path";
import fs from "fs";

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join("uploads")));

const db = await mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "senha",
  database: "fleetflow"
});

await db.query(`CREATE TABLE IF NOT EXISTS files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filename VARCHAR(255),
  filepath TEXT,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)`);

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = "uploads";
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ storage });

app.post("/api/upload", upload.single("file"), async (req, res) => {
  const { filename, path: filepath } = req.file;
  await db.query("INSERT INTO files (filename, filepath) VALUES (?, ?)", [
    filename,
    filepath
  ]);
  res.json({ message: "Upload realizado com sucesso" });
});

app.get("/api/files", async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const offset = (page - 1) * limit;

  const [rows] = await db.query(
    "SELECT * FROM files ORDER BY uploaded_at DESC LIMIT ? OFFSET ?",
    [limit, offset]
  );
  res.json(rows);
});

app.get("/api/preview/:filename", (req, res) => {
  const filePath = path.join("uploads", req.params.filename);
  if (fs.existsSync(filePath)) {
    res.sendFile(path.resolve(filePath));
  } else {
    res.status(404).json({ message: "Arquivo não encontrado" });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
